#include <jni.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <inttypes.h>
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <sstream>
#include <vector>
#include <map>
#include <iomanip>
#include <thread>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/resource.h>
#include <sys/uio.h>
#include <vector>
#include <string>
#include <chrono>
#include <algorithm>
#include <fcntl.h>
#include <android/log.h>
#include <pthread.h>
#include <dirent.h>
#include <list>
#include <libgen.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/un.h>
#include <codecvt>
#include <chrono>
#include <queue>
using namespace std::chrono_literals;
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <sys/system_properties.h>
#include <Files/Helper/android_native_app_glue.h>

#define LOG_TAG "Log Test dbrr"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,LOG_TAG,__VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG,LOG_TAG,__VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,LOG_TAG,__VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR,LOG_TAG,__VA_ARGS__)

#define HOOK(target, hook, original) Tools::Hook((void *)(target), (void *)(hook), (void **)(original))
//Author: @UltimateEngine
#include "../imgui/imgui.h"
#include "../imgui/backends/imgui_impl_android.h"
#include "../imgui/backends/imgui_impl_opengl3.h"
#include "XorStr.h"
#include "obfuscate.h"
#include "json.hpp"
#include "StrEnc.h"
#include "Mau.h"
#include "Vector3.hpp"
#include "Vector2.hpp"
#include "Tools.h"
#include "Log.h"
#include "ImguiPP.h"
#include "font_awesome_6.h"
#include "Font.h"
#include "Icon.h"
#include "Font.h"
#include "OPPOSans-H.h"
#include "QuestrialRegular.h"
#include "roboto.h"
#include "../imgui/imgui_internal.h"
#include "imgui_notify.h"
#include "fake_dlfcn.h"
#include <math.h>
#include "../SDK.hpp"
#include "Files/Oxorany/oxorany.h"
#include "../Hook/Utils.h"
#include "../KittyMemory/MemoryPatch.h"
#include "../Hook/Utils.h"
#include "../Hook/Macros.h"
#include "../Hook/Logger.h"
#include <string.h>
#include <vector>
#include <random>
#include <iostream>
#include <cstdio>
using namespace std;
#include "../../Main/Offset.h"
#include "../../Main/UltimateFiles/Config.h"
#include "../../Main/UltimateFiles/Setting.h"
#include "Files/Helper/skCrypter.h"
#include "User.h"
#include "goku.h"
#include <cstring>
#include <chrono>
#include <stdio.h>
#include <stdlib.h>
#include "../../KeyAuth.hpp"
#include "../../Main/UltimateFiles/virtual_keyboard.h"
#include "LoginAuth.h"
//Author: @UltimateEngine
ImFont *GetBoldFont;
ImFont *Icon;
ImFont *QuestrialRegular;
namespace settings {
    inline ImVec4 particleColour = ImVec4(255, 255, 255, 255);
}

struct TeamColor {
    uint8_t r;
    uint8_t g;
    uint8_t b;
};

ImU32 Black = IM_COL32(0, 0, 0, 255);
ImU32 Green = IM_COL32(0, 255, 0, 255);
ImU32 Yellow = IM_COL32(255, 255, 0, 255);
ImU32 Red = IM_COL32(255, 0, 0, 255);
ImU32 Red2 = IM_COL32(255, 0, 0, 255);
ImU32 White = IM_COL32(255, 255, 255, 255);

struct VECTOR3
{
    float X;
    float Y;
    float Z;
};
ImDrawList* pImGuiDraw;

void DrawBorderString(ImFont *pFont, float FontSize, string Text, float X, float Y, ImColor Color, bool Center)
{
    pImGuiDraw = ImGui::GetBackgroundDrawList();
    if (Setting::textborder)
    {
        ImVec2 TextSize = pFont->CalcTextSizeA(FontSize, FLT_MAX, 0.0f, Text.c_str());
        pImGuiDraw->AddText(pFont, FontSize, ImVec2((X - TextSize.x / 2.0f) + 1.0f, Y + 1.0f), Black, Text.c_str());
        pImGuiDraw->AddText(pFont, FontSize, ImVec2((X - TextSize.x / 2.0f) - 1.0f, Y - 1.0f), Black, Text.c_str());
        pImGuiDraw->AddText(pFont, FontSize, ImVec2((X - TextSize.x / 2.0f) + 1.0f, Y - 1.0f), Black, Text.c_str());
        pImGuiDraw->AddText(pFont, FontSize, ImVec2((X - TextSize.x / 2.0f) - 1.0f, Y + 1.0f), Black, Text.c_str());
        pImGuiDraw->AddText(pFont, FontSize, ImVec2(X - TextSize.x / 2.0f, Y), Color, Text.c_str());
    }
    else
    {

        ImVec2 TextSize = pFont->CalcTextSizeA(FontSize, FLT_MAX, 0.0f, Text.c_str());
        pImGuiDraw->AddText(pFont, FontSize, ImVec2(X - TextSize.x / 2.0f, Y), Color, Text.c_str());
    }
}
void DrawBorderStringW(ImFont *pFont, float FontSize, wstring Text, float X, float Y, ImColor Color, ImColor Color2, bool Center)
{
pImGuiDraw = ImGui::GetBackgroundDrawList();
    std::wstring_convert<std::codecvt_utf8<wchar_t>> myconv;
    std::string Texts = myconv.to_bytes(Text).c_str();
    if (Setting::textborder)
    {
        ImVec2 TextSize = pFont->CalcTextSizeA(FontSize, FLT_MAX, 0.0f, Texts.c_str());
        pImGuiDraw->AddText(pFont, FontSize, ImVec2((X - TextSize.x / 2.0f) + 1.0f, Y + 1.0f), Color2, Texts.c_str());
        pImGuiDraw->AddText(pFont, FontSize, ImVec2((X - TextSize.x / 2.0f) - 1.0f, Y - 1.0f), Color2, Texts.c_str());
        pImGuiDraw->AddText(pFont, FontSize, ImVec2((X - TextSize.x / 2.0f) + 1.0f, Y - 1.0f), Color2, Texts.c_str());
        pImGuiDraw->AddText(pFont, FontSize, ImVec2((X - TextSize.x / 2.0f) - 1.0f, Y + 1.0f), Color2, Texts.c_str());
        pImGuiDraw->AddText(pFont, FontSize, ImVec2(X - TextSize.x / 2.0f, Y), Color, Texts.c_str());
    }
    else
    {
        ImVec2 TextSize = pFont->CalcTextSizeA(FontSize, FLT_MAX, 0.0f, Texts.c_str());
        pImGuiDraw->AddText(pFont, FontSize, ImVec2(X - TextSize.x / 2.0f, Y), Color, Texts.c_str());
    }
}

void DrawFilledRectangle(float X, float Y, float Width, float Height, ImColor Color) {
    pImGuiDraw = ImGui::GetBackgroundDrawList();
    pImGuiDraw->AddRectFilled(ImVec2(X, Y), ImVec2(X - Width, Y - Height), Color);
}
      
void test_DrawLine(ImDrawList* pImGuiDraw, float X1, float Y1, float X2, float Y2, ImColor Color, float Thickness)
{
  pImGuiDraw->AddLine(ImVec2(X1, Y1), ImVec2(X2, Y2), Color, Thickness);
}

void CornerBox(ImDrawList* pImGuiDraw, int x, int y, int w, int h, int thickness, float cornered, ImColor color)
{
  test_DrawLine(pImGuiDraw, x, y, x + (w * cornered), y, color, thickness);
  test_DrawLine(pImGuiDraw, x, y, x, y + (h * cornered), color, thickness);
  // Left Bottom
  test_DrawLine(pImGuiDraw, x, y + h, x + (w * cornered), y + h, color, thickness);
  test_DrawLine(pImGuiDraw, x, y + h, x, (y + h) - (h * cornered), color, thickness);
  // Right Top
  test_DrawLine(pImGuiDraw, x + w, y, (x + w) - (w * cornered), y, color, thickness);
  test_DrawLine(pImGuiDraw, x + w, y, x + w, y + (h * cornered), color, thickness);
  // Right Bottom
  test_DrawLine(pImGuiDraw, x + w, y + h, (x + w) - (w * cornered), y + h, color, thickness);
  test_DrawLine(pImGuiDraw, x + w, y + h, x + w, (y + h) - (h * cornered), color, thickness);
}
bool fileExists(const std::string &filePath)
{

    std::ifstream file(filePath);

    return file.good();
}

void rect_filled(float X, float Y, float Width, float Height, ImColor Color) {
    pImGuiDraw = ImGui::GetBackgroundDrawList();
    pImGuiDraw->AddRectFilled(ImVec2(X, Y), ImVec2(X - Width, Y - Height), Color);
  }

void rect_filled_2(float X, float Y, float Width, float Height, ImColor Color) {
    pImGuiDraw = ImGui::GetBackgroundDrawList();
    pImGuiDraw->AddRectFilled(ImVec2(X, Y), ImVec2(X + Width, Y + Height), Color);
}
// ======================================================================== //

#define IM_CLAMP(V, MN, MX) ((V) < (MN) ? (MN) : (V) > (MX) ? (MX) \
                                                            : (V))
namespace Settings
{
    static int Tab = 1;
}

#define STB_IMAGE_IMPLEMENTATION
#include "../imgui/stb_image.h"



void AddUnderLine(ImColor col_)
{
    ImVec2 min = ImGui::GetItemRectMin();
    ImVec2 max = ImGui::GetItemRectMax();
    min.y = max.y;
    ImGui::GetWindowDrawList()->AddLine(min, max, col_, 1.0f);
}
void TextURL(const char *name_, const char *URL_, uint8_t SameLineBefore_, uint8_t SameLineAfter_)
{
    if (1 == SameLineBefore_)
    {
        ImGui::SameLine(0.0f, ImGui::GetStyle().ItemInnerSpacing.x);
    }
    
    ImGui::PushStyleColor(ImGuiCol_Text, {255, 255, 255, 255});
    ImGui::Text(name_);
    ImGui::PopStyleColor();
    
    if (ImGui::IsItemHovered())
    {
        if (ImGui::IsMouseClicked(0))
        {
            OpenURL(URL_);
        }
        AddUnderLine({255, 193, 000, 255});
//Author: @UltimateEngine
    }
    else
    {
        AddUnderLine({255, 255, 255, 255});
    }
    if (1 == SameLineAfter_)
    {
        ImGui::SameLine(0.0f, ImGui::GetStyle().ItemInnerSpacing.x);
    }
}
void linevertical()
    {
        ImGui::SameLine();
        ImGui::SeparatorEx(ImGuiSeparatorFlags_Vertical);
        ImGui::SameLine();
}
// ===================================================================== \\

std::vector<std::string> pubgPackages = {
    "com.tencent.ig",         // Global
    "com.pubg.krmobile",      // Korea (KR)
    "com.vng.pubgmobile",     // Vietnam (VN)
    "com.rekoo.pubgm",        // Taiwan (TW)
};
// Function to check if a package is installed
bool isPackageInstalled(const std::string& packageName) {
    std::string path = "/data/data/" + packageName; // Common Android app data path
    std::ifstream file(path.c_str());
    return file.good();
}
// Function to detect installed PUBG version
std::string detectPubgVersion() {
    for (const auto& pkg : pubgPackages) {
        if (isPackageInstalled(pkg)) {
            return pkg; // Return the first detected package
        }
    }
    return "PUBG Not Installed"; // If no package is found
}
